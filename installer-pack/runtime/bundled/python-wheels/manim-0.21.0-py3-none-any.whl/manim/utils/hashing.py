"""Utilities for scene caching."""

from __future__ import annotations

import copy
import hashlib
import inspect
import json
import zlib
from collections.abc import Callable, Hashable, Iterable, Sequence
from time import perf_counter
from types import FunctionType, MappingProxyType, MethodType, ModuleType
from typing import TYPE_CHECKING, Any, overload

import numpy as np

from manim._config import config, logger

if TYPE_CHECKING:
    from manim.animation.animation import Animation
    from manim.camera.camera import Camera
    from manim.mobject.mobject import Mobject
    from manim.renderer.opengl_renderer import OpenGLCamera
    from manim.scene.scene import Scene

__all__ = ["KEYS_TO_FILTER_OUT", "get_hash_from_play_call", "get_json"]

# Sometimes there are elements that are not suitable for hashing (too long or
# run-dependent).  This is used to filter them out.
KEYS_TO_FILTER_OUT = {
    "original_id",
    "background",
    "pixel_array",
    "pixel_array_to_cairo_context",
}


def _canonical_field_title(title: Any) -> Any:
    if title is None:
        return None
    title_type = type(title)
    return [f"{title_type.__module__}.{title_type.__qualname__}", repr(title)]


def _canonical_dtype_descriptor(dtype: np.dtype) -> Any:
    canonical = dtype.newbyteorder("<")
    if canonical.names is not None:
        return [
            "struct",
            [
                [
                    name,
                    _canonical_dtype_descriptor(canonical.fields[name][0]),
                    canonical.fields[name][1],
                    _canonical_field_title(canonical.fields[name][2])
                    if len(canonical.fields[name]) > 2
                    else None,
                ]
                for name in canonical.names or ()
            ],
            canonical.itemsize,
            canonical.alignment,
            canonical.isalignedstruct,
        ]
    if canonical.subdtype:
        base, shape = canonical.subdtype
        return ["subarray", _canonical_dtype_descriptor(base), list(shape)]
    return canonical.str


def _hash_ndarray(array: np.ndarray) -> str:
    descriptor = _canonical_dtype_descriptor(array.dtype)
    canonical_dtype = array.dtype.newbyteorder("<")
    digest = hashlib.sha256()
    if canonical_dtype.names is not None:
        for name in canonical_dtype.names or ():
            field_hash = _hash_ndarray(np.asarray(array[name])).encode()
            digest.update(len(field_hash).to_bytes(8, "little"))
            digest.update(field_hash)
    else:
        canonical = np.ascontiguousarray(
            array.astype(canonical_dtype, copy=False),
        )
        digest.update(canonical)
    encoded_descriptor = json.dumps(descriptor, separators=(",", ":"))
    # This compacts array content before the existing CRC32 play-key pipeline.
    return f"NDARRAY:{encoded_descriptor}:{array.shape}:{digest.hexdigest()}"


class _Memoizer:
    """Implements the memoization logic to optimize the hashing procedure and prevent
    the circular references within iterable processed.

    Keeps a record of all the processed objects, and handle the logic to return a place
    holder instead of the original object if the object has already been processed
    by the hashing logic (i.e, recursively checked, converted to JSON, etc..).

    This class uses two signatures functions to keep a track of processed objects :
    hash or id. Whenever possible, hash is used to ensure a broader object
    content-equality detection.
    """

    # Can be changed to whatever string to help debugging the JSON generation.
    ALREADY_PROCESSED_PLACEHOLDER = "AP"
    THRESHOLD_WARNING = 170_000

    def __init__(self) -> None:
        self._already_processed: set[tuple[str, int]] = set()
        # Keep tracked objects alive for this serialization operation. CPython can
        # otherwise reuse a transient object's address before encoding has completed;
        # this also matters for objects whose hash is derived from their identity.
        self._keep_alive: dict[int, Any] = {}

    def check_already_processed_decorator(self, is_method: bool = False) -> Callable:
        """Decorator to handle the arguments that goes through the decorated function.
        Returns the value of ALREADY_PROCESSED_PLACEHOLDER if the obj has been processed,
        or lets the decorated function call go ahead.

        Parameters
        ----------
        is_method
            Whether the function passed is a method, by default False.
        """

        def layer(func: Callable[[Any], Any]) -> Callable:
            # NOTE : There is probably a better way to separate both case when func is
            # a method or a function.
            if is_method:
                return lambda obj_self, obj: self._handle_already_processed(
                    obj,
                    default_function=lambda obj: func(obj_self, obj),
                )
            return lambda obj: self._handle_already_processed(
                obj, default_function=func
            )

        return layer

    def check_already_processed(self, obj: Any) -> Any:
        """Checks if obj has been already processed. Returns itself if it has not been,
        or the value of ALREADY_PROCESSED_PLACEHOLDER if it has.
        Marks the object as processed in the second case.

        Parameters
        ----------
        obj
            The object to check.

        Returns
        -------
        Any
            Either the object itself or the placeholder.
        """
        # When the object is not memoized, we return the object itself.
        return self._handle_already_processed(obj, lambda x: x)

    def mark_as_processed(self, obj: Any) -> None:
        """Marks an object as processed.

        Parameters
        ----------
        obj
            The object to mark as processed.
        """
        self._handle_already_processed(obj, lambda x: x)
        self._return(obj, id, lambda x: x, memoizing=False)

    def _handle_already_processed(
        self,
        obj: Any,
        default_function: Callable[[Any], Any],
    ) -> str | Any:
        if isinstance(
            obj,
            (
                int,
                float,
                str,
                complex,
            ),
        ) and obj not in [None, self.ALREADY_PROCESSED_PLACEHOLDER]:
            # It makes no sense (and it'd slower) to memoize objects of these primitive
            # types.  Hence, we simply return the object.
            return obj
        if isinstance(obj, Hashable):
            try:
                return self._return(obj, hash, default_function)
            except TypeError:
                # In case of an error with the hash (eg an object is marked as hashable
                # but contains a non hashable within it)
                # Fallback to use the built-in function id instead.
                pass
        return self._return(obj, id, default_function)

    def _return(
        self,
        obj: Any,
        obj_to_membership_sign: Callable[[Any], int],
        default_func: Callable[[Any], Any],
        memoizing: bool = True,
    ) -> str | Any:
        # hash() values and id() addresses are both raw ints that share no meaning, so entries are tagged with
        # their signature kind: in an untagged set, a hash() value that numerically equals a recorded id() address
        # (or vice versa) collapses a never-processed object to the placeholder.
        sign_kind = "h" if obj_to_membership_sign is hash else "i"
        signature = obj_to_membership_sign(obj)
        obj_membership_sign = (sign_kind, signature)
        if obj_membership_sign in self._already_processed:
            return self.ALREADY_PROCESSED_PLACEHOLDER
        if memoizing:
            if (
                not config.disable_caching_warning
                and len(self._already_processed) == self.THRESHOLD_WARNING
            ):
                logger.warning(
                    "It looks like the scene contains a lot of sub-mobjects. Caching "
                    "is sometimes not suited to handle such large scenes, you might "
                    "consider disabling caching with --disable_caching to potentially "
                    "speed up the rendering process.",
                )
                logger.warning(
                    "You can disable this warning by setting disable_caching_warning "
                    "to True in your config file.",
                )

            self._already_processed.add(obj_membership_sign)
            self._keep_alive.setdefault(id(obj), obj)
        return default_func(obj)


class _CustomEncoder(json.JSONEncoder):
    def __init__(
        self,
        *args: Any,
        memoizer: _Memoizer,
        include_pixel_array: bool = False,
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, **kwargs)
        self._memoizer = memoizer
        self.include_pixel_array = include_pixel_array

    def default(self, obj: Any) -> Any:
        """This method is used to serialize objects to JSON format.

        If obj is a function, then it will return a dict with two keys : 'code', for
        the code source, and 'nonlocals' for all nonlocalsvalues. (including nonlocals
        functions, that will be serialized as this is recursive.)
        if obj is a np.darray, it converts it into a list.
        if obj is an object with __dict__ attribute, it returns its __dict__.
        Else, will let the JSONEncoder do the stuff, and throw an error if the type is
        not suitable for JSONEncoder.

        Parameters
        ----------
        obj
            Arbitrary object to convert

        Returns
        -------
        Any
            Python object that JSON encoder will recognize

        """
        if not (isinstance(obj, ModuleType)) and isinstance(
            obj,
            (MethodType, FunctionType),
        ):
            cvars = inspect.getclosurevars(obj)
            cvardict = {**copy.copy(cvars.globals), **copy.copy(cvars.nonlocals)}
            for i in list(cvardict):
                # NOTE : All module types objects are removed, because otherwise it
                # throws ValueError: Circular reference detected if not. TODO
                if isinstance(cvardict[i], ModuleType):
                    del cvardict[i]
            try:
                code = inspect.getsource(obj)
            except (OSError, TypeError):
                # This happens when rendering videos included in the documentation
                # within doctests and should be replaced by a solution avoiding
                # hash collision (due to the same, empty, code strings) at some point.
                # See https://github.com/ManimCommunity/manim/pull/402.
                code = ""
            return self._cleaned_iterable({"code": code, "nonlocals": cvardict})
        elif isinstance(obj, np.ndarray):
            if obj.__class__ is not np.ndarray or obj.dtype.hasobject:
                if obj.size > 1000:
                    obj = np.resize(obj, (100, 100))
                    return f"TRUNCATED ARRAY: {repr(obj)}"
                return repr(obj)
            return _hash_ndarray(obj)
        elif hasattr(obj, "__dict__"):
            temp = obj.__dict__
            # MappingProxy is scene-caching nightmare. It contains all of the object methods and attributes. We skip it as the mechanism will at some point process the object, but instantiated.
            # Indeed, there is certainly no case where scene-caching will receive only a non instancied object, as this is never used in the library or encouraged to be used user-side.
            if isinstance(temp, MappingProxyType):
                return "MappingProxy"
            return self._cleaned_iterable(temp)
        elif isinstance(obj, np.uint8):
            return int(obj)
        # Serialize it with only the type of the object. You can change this to whatever string when debugging the serialization process.
        return str(type(obj))

    @overload
    def _cleaned_iterable(self, iterable: Sequence[Any]) -> list[Any]: ...

    @overload
    def _cleaned_iterable(self, iterable: dict[Any, Any]) -> dict[Any, Any]: ...

    def _cleaned_iterable(self, iterable):
        """Check for circular reference at each iterable that will go through the JSONEncoder, as well as key of the wrong format.

        If a key with a bad format is found (i.e not a int, string, or float), it gets replaced by its hash using the same process implemented here.
        If a circular reference is found within the iterable, it will be replaced by the value of ALREADY_PROCESSED_PLACEHOLDER.

        Parameters
        ----------
        iterable
            The iterable to check.
        """

        def _key_to_hash(key: Any) -> int:
            return zlib.crc32(_get_json(key, self._memoizer).encode())

        def _iter_check_list(lst: Sequence[Any]) -> list[Any]:
            processed_list = [None] * len(lst)
            for i, el in enumerate(lst):
                el = self._memoizer.check_already_processed(el)
                if isinstance(el, (list, tuple)):
                    new_value = _iter_check_list(el)
                elif isinstance(el, dict):
                    new_value = _iter_check_dict(el)
                else:
                    new_value = el
                processed_list[i] = new_value
            return processed_list

        def _iter_check_dict(dct: dict[Any, Any]) -> dict[Any, Any]:
            processed_dict = {}
            for k, v in dct.items():
                v = self._memoizer.check_already_processed(v)
                if k in KEYS_TO_FILTER_OUT and not (
                    self.include_pixel_array and k == "pixel_array"
                ):
                    continue
                # We check if the k is of the right format (supported by JSON)
                if not isinstance(k, (str, int, float, bool)) and k is not None:
                    k_new = _key_to_hash(k)
                else:
                    k_new = k
                if isinstance(v, dict):
                    new_value = _iter_check_dict(v)
                elif isinstance(v, (list, tuple)):
                    new_value = _iter_check_list(v)
                else:
                    new_value = v
                processed_dict[k_new] = new_value
            return processed_dict

        if isinstance(iterable, (list, tuple)):
            return _iter_check_list(iterable)
        elif isinstance(iterable, dict):
            return _iter_check_dict(iterable)
        else:
            raise TypeError("'iterable' is neither an iterable nor a dictionary.")

    def encode(self, obj: Any) -> str:
        """Overriding of :meth:`JSONEncoder.encode`, to make our own process.

        Parameters
        ----------
        obj
            The object to encode in JSON.

        Returns
        -------
        :class:`str`
           The object encoder with the standard json process.
        """
        self._memoizer.mark_as_processed(obj)
        if isinstance(obj, (dict, list, tuple)):
            return super().encode(self._cleaned_iterable(obj))
        return super().encode(obj)


def _get_json(
    obj: Any, memoizer: _Memoizer, *, include_pixel_array: bool = False
) -> str:
    """Serialize ``obj`` using an existing serialization-operation memoizer."""
    return json.dumps(
        obj,
        cls=_CustomEncoder,
        memoizer=memoizer,
        include_pixel_array=include_pixel_array,
    )


def get_json(obj: Any, *, include_pixel_array: bool = False) -> str:
    """Recursively serialize `object` to JSON using the :class:`CustomEncoder` class.

    Parameters
    ----------
    obj
        The dict to flatten
    include_pixel_array
        Whether to include pixel arrays encountered while flattening the object.

    Returns
    -------
    :class:`str`
        The flattened object
    """
    return _get_json(obj, _Memoizer(), include_pixel_array=include_pixel_array)


def get_hash_from_play_call(
    scene_object: Scene,
    camera_object: Camera | OpenGLCamera,
    animations_list: Iterable[Animation],
    current_mobjects_list: Iterable[Mobject],
) -> str:
    """Take the list of animations and a list of mobjects and output their hashes. This is meant to be used for `scene.play` function.

    Parameters
    -----------
    scene_object
        The scene object.

    camera_object
        The camera object used in the scene.

    animations_list
        The list of animations.

    current_mobjects_list
        The list of mobjects.

    Returns
    -------
    :class:`str`
        A string concatenation of the respective hashes of `camera_object`, `animations_list` and `current_mobjects_list`, separated by `_`.
    """
    logger.debug("Hashing ...")
    t_start = perf_counter()
    memoizer = _Memoizer()
    memoizer.mark_as_processed(scene_object)
    camera_json = _get_json(camera_object, memoizer)
    animations_list_json = [
        _get_json(animation, memoizer, include_pixel_array=True)
        for animation in sorted(animations_list, key=str)
    ]
    current_mobjects_list_json = [
        _get_json(mobject, memoizer, include_pixel_array=True)
        for mobject in current_mobjects_list
    ]
    hash_camera, hash_animations, hash_current_mobjects = (
        zlib.crc32(repr(json_val).encode())
        for json_val in [camera_json, animations_list_json, current_mobjects_list_json]
    )
    hash_complete = f"{hash_camera}_{hash_animations}_{hash_current_mobjects}"
    t_end = perf_counter()
    logger.debug("Hashing done in %(time)s s.", {"time": str(t_end - t_start)[:8]})
    logger.debug("Hash generated :  %(h)s", {"h": hash_complete})
    return hash_complete
