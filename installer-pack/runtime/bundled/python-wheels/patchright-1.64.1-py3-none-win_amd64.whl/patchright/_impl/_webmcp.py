from typing import TYPE_CHECKING, Any, List
from patchright._impl._api_structures import WebMCPTool
from patchright._impl._helper import locals_to_params
from patchright._impl._js_handle import Serializable, parse_result, serialize_argument

if TYPE_CHECKING:
    from patchright._impl._frame import Frame


class WebMCP:
    def __init__(self, frame: "Frame") -> None:
        self._frame = frame
        self._loop = frame._loop
        self._dispatcher_fiber = frame._dispatcher_fiber

    async def tools(self, timeout: float = None) -> List[WebMCPTool]:
        return await self._frame._channel.send(
            "webmcpTools", self._frame._timeout, locals_to_params(locals())
        )

    async def call_tool(
        self, name: str, input: Serializable = None, timeout: float = None
    ) -> Any:
        result = await self._frame._channel.send(
            "webmcpCallTool",
            self._frame._timeout,
            {"name": name, "input": serialize_argument(input), "timeout": timeout},
        )
        return parse_result(result)
