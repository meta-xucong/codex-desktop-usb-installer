import inspect
import sys
from typing import Any, Callable

if sys.version_info < (3, 14):

    def signature(fn: Callable[..., Any]) -> inspect.Signature:
        return inspect.signature(fn)
else:
    from annotationlib import Format

    def signature(fn: Callable[..., Any]) -> inspect.Signature:
        return inspect.signature(fn, annotation_format=Format.FORWARDREF)
