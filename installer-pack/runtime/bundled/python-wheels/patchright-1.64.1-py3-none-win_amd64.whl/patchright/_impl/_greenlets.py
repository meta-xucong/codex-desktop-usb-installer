import asyncio
import os
from typing import Tuple
import greenlet
from patchright._impl._errors import TargetClosedError


def _greenlet_trace_callback(
    event: str, args: Tuple[greenlet.greenlet, greenlet.greenlet]
) -> None:
    if event in ("switch", "throw"):
        origin, target = args
        print(f"Transfer from {origin} to {target} with {event}")


if os.environ.get("INTERNAL_PW_GREENLET_DEBUG"):
    greenlet.settrace(_greenlet_trace_callback)


class MainGreenlet(greenlet.greenlet):
    def __str__(self) -> str:
        return "<MainGreenlet>"


class RouteGreenlet(greenlet.greenlet):
    def __str__(self) -> str:
        return "<RouteGreenlet>"


class LocatorHandlerGreenlet(greenlet.greenlet):
    def __str__(self) -> str:
        return "<LocatorHandlerGreenlet>"


class EventGreenlet(greenlet.greenlet):
    def __str__(self) -> str:
        return "<EventGreenlet>"


def connection_closed_error() -> TargetClosedError:
    return TargetClosedError("Playwright connection closed")


def wait_for_future(
    loop: asyncio.AbstractEventLoop,
    dispatcher_fiber: greenlet.greenlet,
    future: "asyncio.Future",
) -> None:
    __tracebackhide__ = True
    g_self = greenlet.getcurrent()

    def resume(_: "asyncio.Future") -> None:
        g_self.switch()

    future.add_done_callback(resume)
    try:
        while not future.done():
            if dispatcher_fiber.dead:
                raise connection_closed_error()
            dispatcher_fiber.switch()
    except BaseException:
        future.remove_done_callback(resume)
        future.cancel()
        raise
    finally:
        if not dispatcher_fiber.dead:
            asyncio._set_running_loop(loop)
